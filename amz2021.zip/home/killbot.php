<?php
error_reporting(0);
session_start();

/**
 * READ ME!
 * 
 * 1. Change 'YOUR_APIKEY' with your own apikey that you can found at https://killbot.org/developers
 * Eeample: 
 * 
 * $config_killbot['apikey'] = '4KUQqw0A0Pf72vCLS2YhrsEqZl8soxwHvw_Y6WyVTF8oJ';
 * 
 * 2. Select your detection type using is_bot or block_access parameter. What is it?
 * - Option 1 = using 'is_bot', means it will block every access that is detected as bots without exception
 * (ID: menggunakan opsi 1 / 'is_bot', berarti akan memblok setiap akses yang terdeteksi sebagai bot tanpa terkecuali)
 * - Option 2 = using 'block_access', bots that are detected will not be blocked immediately but instead depending on your settings on https://killbot.org/blocker, so if you choose the block type option 'NO BLOCKED' then there will be no blocking.
 * (ID: menggunakan opsi 2 / 'block_access', bot yang terdeteksi tidak akan langsung diblokir melainkan tergantung settinganmu pada https://killbot.org/blocker, jadi jika kamu memilih opsi tipe block 'NO BLOCKED' maka tidak akan terjadi pemblockan.)
 * Example:
 * 
 * $config_killbot['detect_by'] = 2;
 * 
*/

$config_killbot['apikey'] = trim(file_get_contents('killbot.ini')); // https://killbot.org/developers

if (isset($config_killbot['apikey'])) {
	$config_killbot['detect_by'] = 2; // Detection by parameter 'is_bot' or 'block_access'. Option 1 = 'is_bot' and 2 = 'block_access'
	$randomid = sha1(rand(0,10000));
	function get_ip()
	{
		$client = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote = $_SERVER['REMOTE_ADDR'];

		if (filter_var($client, FILTER_VALIDATE_IP)) {
			$ip = $client;
		} elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
			$ip = $forward;
		} else {
			$ip = $remote;
		}
	}

	$ip = get_ip();
	    $ch = curl_init();
	    curl_setopt($ch, CURLOPT_USERAGENT, "Killbot Blocker");
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_URL, "https://killbot.org/api/v1/blocker?ip=".$ip."&apikey=".$config_killbot['apikey']."&ua=".urlencode($_SERVER['HTTP_USER_AGENT'])."&url=".urlencode($_SERVER['REQUEST_URI']));
	    $data = curl_exec($ch);
	    curl_close($ch);

	    $_SESSION['killbot_session'] = true;

	    $json = json_decode($data, true);
	    $meta = $json['meta']['code'];
	    $blocked = $config_killbot['detect_by'] == 1 ? $json['data']['is_bot'] : $json['data']['block_access'];

	    if($meta = 200 && $blocked){
	        $_SESSION['is_bot']  = true;

	        $file = fopen("killbot-block.txt","a");
	        $message = $ip."\n";
	        fwrite($file, $message);
	        fclose($file);
	        $click = fopen("result/total_bot.txt","a");
	        fwrite($click,"$ip (Detect by Killbot Blocker)"."\n");
	        fclose($click);

	        header('HTTP/1.0 403 Forbidden');
	        die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p><p>Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.</p></body></html>');
	    } else{
	        $_SESSION['is_bot']  = false;
	    }
}
?>