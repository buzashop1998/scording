<?php
session_start();
require_once('../main.php');
require_once("../blocker.php");
require_once("../blocker3.php");
?>
